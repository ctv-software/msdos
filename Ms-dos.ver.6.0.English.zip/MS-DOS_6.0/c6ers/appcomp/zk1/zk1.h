/* TS = none */
/*
**  ZK1.H -- Defines and externs for ZK1 compression/decompression
*/

#include "..\lzss\lz.h"

#define  cbStrMax   (16 + cbIndex)  /* upper limit for match_length */
