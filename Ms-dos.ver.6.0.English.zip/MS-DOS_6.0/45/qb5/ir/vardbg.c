/*** 
*vardbg.c - non-release code to validate varmgr.c
*
*	Copyright <C> 1986,1987 Microsoft Corporation
*
*Purpose:
*	contains routines used for debugging the variable manager; These routines
*	are pretty verion-specific, and so have been moved out of vardebug.c.
*
*******************************************************************************/
#include "version.h"
