/*
	CW : Character Windows

	private.c : Includes headers for making .inc files
	NOTE: does not include all headers, just those needed for assembler
*/

#define COW
#include <cow.h>		/* NOTE: cow.inc not generated !! */

