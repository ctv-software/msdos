/*
	COW : Character Oriented Windows

	cowextras.h : Extra routines in COW
	(do not rely on these routines : unofficially exported / supported)
*/

DWORD		FARPUBLIC SendMessageToSibbling(PWND, WORD, WORD, DWORD);
