/*
	COW : Character Oriented Windows

	sdmver.h : sdm version control
*/

/***BEGIN_PUBLIC***/

#define	SDM_COW		1
/* #define SDM_ST */
/* #define SDM_LOCK */

/***END_PUBLIC***/

