/*  COMM.H  */

void processSetComputerId(void);
void processSingleUser(void);
void processGen(void);
void processComm(void);
void processBaudrate(void);
