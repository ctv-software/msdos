/*  MOU.H  */


void processMouClick(void);
void processMouDoubleClick(void);
void processMouLock(void);
void processMouRel(void);
void processMouReset(void);
void processMouMove(void);
void collectMoveByte(void);
void collectMoveInteger(void);
void moveTheMouseRelative(void);
void processMouGoto(void);
void collectGotoByte(void);
void collectGotoInteger(void);
void moveTheMouseAbsolute(void);
void processMou(void);

